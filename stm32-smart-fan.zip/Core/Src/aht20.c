#include "aht20.h"
#include "stm32f1xx_hal.h"
#include "main.h"

void AHT20_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t init_cmd[3] = {0xBE, 0x08, 0x00};
    HAL_I2C_Master_Transmit(hi2c, AHT20_ADDRESS, init_cmd, 3, HAL_MAX_DELAY);
    HAL_Delay(50);
}

void AHT20_ReadData(I2C_HandleTypeDef *hi2c, float *temperature, float *humidity) {
    uint8_t trigger_cmd[3] = {0xAC, 0x33, 0x00};
    uint8_t data[6];

    HAL_I2C_Master_Transmit(hi2c, AHT20_ADDRESS, trigger_cmd, 3, HAL_MAX_DELAY);
    HAL_Delay(80);
    HAL_I2C_Master_Receive(hi2c, AHT20_ADDRESS, data, 6, HAL_MAX_DELAY);

    uint32_t raw_hum = ((uint32_t)data[1] << 12) | ((uint32_t)data[2] << 4) | (data[3] >> 4);
    uint32_t raw_temp = ((uint32_t)(data[3] & 0x0F) << 16) | ((uint32_t)data[4] << 8) | data[5];

    *humidity = ((float)raw_hum / 1048576.0) * 100.0;
    *temperature = ((float)raw_temp / 1048576.0) * 200.0 - 50.0;
}
