#include "main.h"
#include "aht20.h"
#include "oled.h"
#include "relay.h"
#include "stdio.h"

I2C_HandleTypeDef hi2c1;
float temperature = 0.0;
float humidity = 0.0;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);

int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_I2C1_Init();
    OLED_Init(&hi2c1);
    AHT20_Init(&hi2c1);
    Relay_Init();

    while (1) {
        AHT20_ReadData(&hi2c1, &temperature, &humidity);
        char line1[20], line2[20];
        sprintf(line1, "Temp: %.1f C", temperature);
        sprintf(line2, "Hum: %.1f %%", humidity);
        OLED_Clear(&hi2c1);
        OLED_ShowString(&hi2c1, 0, 0, line1);
        OLED_ShowString(&hi2c1, 2, 0, line2);
        if (temperature > 28.0) Relay_On();
        else Relay_Off();
        HAL_Delay(1000);
    }
}
