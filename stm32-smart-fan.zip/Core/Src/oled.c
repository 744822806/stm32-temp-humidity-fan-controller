#include "oled.h"
#define OLED_ADDR 0x78

static void OLED_SendCommand(I2C_HandleTypeDef *hi2c, uint8_t cmd) {
    uint8_t data[2] = {0x00, cmd};
    HAL_I2C_Master_Transmit(hi2c, OLED_ADDR, data, 2, HAL_MAX_DELAY);
}

static void OLED_SendData(I2C_HandleTypeDef *hi2c, uint8_t *data, uint16_t size) {
    uint8_t buffer[129];
    buffer[0] = 0x40;
    memcpy(&buffer[1], data, size);
    HAL_I2C_Master_Transmit(hi2c, OLED_ADDR, buffer, size + 1, HAL_MAX_DELAY);
}

void OLED_Init(I2C_HandleTypeDef *hi2c) {
    HAL_Delay(100);
    OLED_SendCommand(hi2c, 0xAE);
    OLED_SendCommand(hi2c, 0xA6);
    OLED_SendCommand(hi2c, 0xAF);
}

void OLED_Clear(I2C_HandleTypeDef *hi2c) {
    uint8_t clear[128] = {0};
    for (uint8_t i = 0; i < 8; i++) {
        OLED_SendCommand(hi2c, 0xB0 + i);
        OLED_SendCommand(hi2c, 0x00);
        OLED_SendCommand(hi2c, 0x10);
        OLED_SendData(hi2c, clear, 128);
    }
}

void OLED_ShowString(I2C_HandleTypeDef *hi2c, uint8_t row, uint8_t col, char *str) {
    char buffer[32];
    sprintf(buffer, "%s", str);
    OLED_SendCommand(hi2c, 0xB0 + row);
    OLED_SendCommand(hi2c, 0x00 + (8 * col & 0x0F));
    OLED_SendCommand(hi2c, 0x10 + ((8 * col >> 4) & 0x0F));
    OLED_SendData(hi2c, (uint8_t*)buffer, strlen(buffer));
}
