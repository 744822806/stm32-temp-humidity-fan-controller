#ifndef __AHT20_H
#define __AHT20_H
#include "stm32f1xx_hal.h"
#define AHT20_ADDRESS 0x38 << 1
void AHT20_Init(I2C_HandleTypeDef *hi2c);
void AHT20_ReadData(I2C_HandleTypeDef *hi2c, float *temperature, float *humidity);
#endif
