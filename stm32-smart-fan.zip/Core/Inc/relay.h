#ifndef __RELAY_H
#define __RELAY_H
#include "stm32f1xx_hal.h"
void Relay_Init(void);
void Relay_On(void);
void Relay_Off(void);
#endif
