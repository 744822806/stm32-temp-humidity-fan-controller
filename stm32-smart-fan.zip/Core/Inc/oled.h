#ifndef __OLED_H
#define __OLED_H
#include "stm32f1xx_hal.h"
#include <string.h>
#include <stdio.h>
void OLED_Init(I2C_HandleTypeDef *hi2c);
void OLED_Clear(I2C_HandleTypeDef *hi2c);
void OLED_ShowString(I2C_HandleTypeDef *hi2c, uint8_t row, uint8_t col, char *str);
#endif
