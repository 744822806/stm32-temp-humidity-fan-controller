# STM32 Smart Fan Controller (AHT20 + OLED + Relay)
An IoT-style STM32 project that reads temperature and humidity using the AHT20 sensor, displays data on an OLED screen, and controls a fan automatically through a relay.
